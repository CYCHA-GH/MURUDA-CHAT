package com.example.chatbotleedaun;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ArrayParser {
    public static String parser() throws FileNotFoundException {
        JsonParser parser1 = new JsonParser();
        Object obj = parser1.parse( new FileReader(
                "response.json"));
        Object obj2 = parser1.parse( new FileReader(
                "ask.json"));
        JsonObject jObject1 = (JsonObject) obj;
        JsonObject jObject2 = (JsonObject) obj2;

        JsonElement ask = jObject1.get("values");
        JsonArray askHead = jObject2.getAsJsonArray("values");
        System.out.println(ask);
        System.out.println(askHead.get(0));
        return "";
    }
}
