package com.example.chatbotleedaun;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class UserCommandMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_command_menu);

        Intent intent = new Intent(UserCommandMenu.this, UserCommandExample.class);
        startActivity(intent);

        finish();
    }
}
