package com.example.chatbotleedaun;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class UserCommandExample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_command_example);

        getSupportActionBar().setTitle("사용자 명령어 도움말");

    }
}
