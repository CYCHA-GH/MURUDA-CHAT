package com.example.chatbotleedaun;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<ChatData> myDataList = null;

    MyAdapter(ArrayList<ChatData> dataList){
        myDataList = dataList;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        Context context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (viewType == Code.ViewType.CENTER_CONTENT) {
            view = inflater.inflate(R.layout.center_content, parent, false);
            return new CenterViewHolder(view);
        } else if (viewType == Code.ViewType.LEFT_CONTENT) {
            view = inflater.inflate(R.layout.chat_msgbox, parent, false);
            return new LeftViewHolder(view);
        } else{
            view = inflater.inflate(R.layout.user_msgbox, parent, false);
            return new RightViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        if(viewHolder instanceof CenterViewHolder)
        {
            ((CenterViewHolder) viewHolder).content.setText(myDataList.get(position).getContent());
        }
        else if(viewHolder instanceof LeftViewHolder)
        {
            ((LeftViewHolder) viewHolder).content.setText(myDataList.get(position).getContent());
        }
        else
        {
            ((RightViewHolder) viewHolder).content.setText(myDataList.get(position).getContent());
        }
    }

    @Override
    public int getItemCount() {
        return myDataList.size();
    }
    @Override
    public int getItemViewType(int position) {
        return myDataList.get(position).getViewType();
    }

    public class LeftViewHolder extends RecyclerView.ViewHolder {
        TextView content;
        ImageView image;

        LeftViewHolder(View itemView)
        {
            super(itemView);

            content = itemView.findViewById(R.id.content);
            image = itemView.findViewById(R.id.meoluda_circle);
        }
    }

    class RightViewHolder extends RecyclerView.ViewHolder {
        TextView content;

        RightViewHolder(View itemView)
        {
            super(itemView);
            content = itemView.findViewById(R.id.content);
        }
    }

    class CenterViewHolder extends RecyclerView.ViewHolder {
        TextView content;
        CenterViewHolder(View itemView)
        {
            super(itemView);
            content = itemView.findViewById(R.id.content);
        }
    }
}
