package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Question extends AppCompatActivity {

    TextView Tv_Title,Tv_Content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content = findViewById(R.id.tv_content);
        Tv_Title.setText("학업관련");
        Tv_Content.setText("수강신청 원격수업 전자출결 출결조회방법 등록금 " +
                "로그인 성적조회 강의평가 자기진단평가 자가진단평가방법 졸업학점 " +
                "계절학기 학과일정 학사학위");
    }
}