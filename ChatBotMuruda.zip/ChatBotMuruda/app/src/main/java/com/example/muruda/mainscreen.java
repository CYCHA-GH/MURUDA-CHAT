package com.example.muruda;

public class mainscreen {
    String name;
    String text;
    String pofile;

    public mainscreen(){}
    public mainscreen(String text){
        this.text=text;
    }
    public mainscreen(String text, String pofile){
        this(text);
        this.pofile=pofile;
    }


    public String getName() {
        return name;
    }

    public String getText() {
        return text;
    }

    public String getPofile() {
        return pofile;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setPofile(String pofile) {
        this.pofile = pofile;
    }
}
