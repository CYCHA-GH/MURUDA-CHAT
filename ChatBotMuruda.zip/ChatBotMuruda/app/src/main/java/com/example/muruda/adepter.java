package com.example.muruda;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class adepter extends BaseAdapter {
    ArrayList<mainscreen> messageitems;
    LayoutInflater layoutInflater;

    public adepter(ArrayList<mainscreen> messageitems, LayoutInflater layoutInflater){
        this.messageitems = messageitems;
        this.layoutInflater = layoutInflater;
    }

    @Override
    public int getCount(){
        return messageitems.size();
    }

    @Override
    public Object getItem(int position){
        return messageitems.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup){
        //현재 보여줄 번째의(position)의 데이터로 뷰를 생성
        mainscreen item = messageitems.get(position);
        String profile = item.getPofile();

        //재활용할 뷰는 사용하지 않음
        View itemView=null;
        TextView tvbname;
        if(profile!="머루다"){
            itemView=layoutInflater.inflate(R.layout.activity_mychat,viewGroup,false);}
        else{
            itemView=layoutInflater.inflate(R.layout.activity_murudachat,viewGroup,false);
        }
            //만들어진 itemView에 값들 설정
        TextView tvbchat = itemView.findViewById(R.id.tvb_muruchat);

        tvbchat.setText(item.getText());
        return itemView;
        }

}
