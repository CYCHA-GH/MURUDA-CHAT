package com.example.muruda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    adepter adepter;
    ListView listView;
    ArrayList<mainscreen> messageitems=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=findViewById(R.id.ListVeiw);
        adepter=new adepter(messageitems,getLayoutInflater());
        listView.setAdapter(adepter);

        mainscreen messageitem = new mainscreen("안녕, 머루다에 온걸 환영해","머루다");
        //arraylist에 값추가
        messageitems.add(messageitem);

        //리스트뷰 갱신
        adepter.notifyDataSetChanged();
        listView.setSelection(messageitems.size()-1);
    }
    public void clickSend(View view){

    }
}