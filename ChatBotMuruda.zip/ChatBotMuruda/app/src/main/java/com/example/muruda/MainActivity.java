package com.example.muruda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

import javax.security.auth.login.LoginException;

public class MainActivity extends AppCompatActivity {
    adepter adepter;
    ListView listView;
    Button btnsend;

    ArrayList<mainscreen> messageitems=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = new Intent(this, loadScreen.class);
        startActivity(intent);

        btnsend = findViewById(R.id.btn_send);

        listView=findViewById(R.id.ListVeiw);
        adepter=new adepter(messageitems,getLayoutInflater());
        listView.setAdapter(adepter);

        mainscreen messageitem = new mainscreen("안녕, 머루다에 온걸 환영해","머루다");
        //arraylist에 값추가
        messageitems.add(messageitem);

        //리스트뷰 갱신
        adepter.notifyDataSetChanged();
        listView.setSelection(messageitems.size()-1);

        btnsend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }

}