package com.example.muruda;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class loadScreen extends AppCompatActivity {
    ImageView imgload;
    TextView txvloadtitle,txvloadsubtitle;
    private static final int _Width = 300;
    private static final int _Height = 400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_screen);


        imgload = (ImageView)findViewById(R.id.img_load);
        txvloadsubtitle = (TextView)findViewById(R.id.txb_loadsubtitle);
        txvloadtitle = (TextView)findViewById(R.id.txv_loadtitle);

        ObjectAnimator animator = ObjectAnimator.ofFloat(imgload, "translationY", imgload.getY()-200);
        Animation anim = AnimationUtils.loadAnimation(this,R.anim.alpha_anim);
        animator.setDuration(1500);
        animator.start();

        txvloadtitle.startAnimation(anim);
        txvloadsubtitle.startAnimation(anim);
    }
}
