package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<ChatData> dataList;
    private MyAdapter itemAdapter;

    EditText EditText_chat;
    Button Button_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button_send = findViewById(R.id.Button_send);
        EditText_chat = findViewById(R.id.EditText_chat);

        this.initializeData();
        itemAdapter = new MyAdapter(dataList);
        //Adapt,ChatData를 이용하여 채팅 내용 뽑기
        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        LinearLayoutManager manager =
                new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(manager); //LayoutManager 등록
        recyclerView.setAdapter(itemAdapter); // Adapter 등록
        AssetManager assetManager= getAssets();
        try {
            InputStream obj1 = assetManager.open("json/ask.json");
            InputStreamReader jObject1 = new InputStreamReader(obj1);
            BufferedReader reader1 = new BufferedReader(jObject1);

            StringBuffer buffer1 = new StringBuffer();
            String line1 = reader1.readLine();
            while(line1!=null ){
                buffer1.append(line1+"\n");
                line1 = reader1.readLine();
            }
            String jsonData1 = buffer1.toString();
            JSONObject jsonObject1 = new JSONObject(jsonData1);

            Button_send.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String msg = EditText_chat.getText().toString();
                    //입력받은 값을 우측에 출력후 좌측에 알맞은 답변 생성
                    if((msg.getBytes().length<=0))  {
                        Toast.makeText(getApplicationContext(),"내용을 입력하세요",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        dataList.add(new ChatData(msg, null, Code.ViewType.RIGHT_CONTENT));
                        //공백제거, 소문자 -> 대문자
                        String sMsg = msg.replace(" ","").trim().toUpperCase();
                        itemAdapter.notifyDataSetChanged();
                        EditText_chat.setText("");
                        try {
                            String ask = jsonObject1.getString(sMsg);
                            dataList.add(new ChatData(ask, null, Code.ViewType.LEFT_CONTENT));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        recyclerView.scrollToPosition(dataList.size()-1);
                    }
                }
            });
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void initializeData() {
        dataList = new ArrayList<>();
        //CENTER 출력
        dataList.add(new ChatData("머 루 다 \n",null,Code.ViewType.CENTER_CONTENT));
        //LEFT 출력
        dataList.add(new ChatData("안녕! 원하는 질문을 말해줘\n ex)수강신청,강의실번호:E202",null,Code.ViewType.LEFT_CONTENT));
    }
}