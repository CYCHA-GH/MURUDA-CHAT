package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<ChatData> dataList;

    EditText EditText_chat;
    Button Button_send;
    String msg = EditText_chat.getText().toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button_send = findViewById(R.id.Button_send);
        EditText_chat = findViewById(R.id.EditText_chat);

        //버튼을 눌렀을때
        Button_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    Toast.makeText(getApplicationContext(),msg,Toast.LENGTH_LONG).show();
            }
        });

        //Adapt,ChatData를 이용하여 채팅 내용 뽑기
        this.initializeData();

        RecyclerView recyclerView = findViewById(R.id.my_recycler_view);

        LinearLayoutManager manager =
                new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);

        recyclerView.setLayoutManager(manager); //LayoutManager 등록
//        recyclerView.setAdapter(new MyAdapter(dataList)); // Adapter 등록
    }

    private void initializeData() {
//        dataList = new ArrayList<>;
//        //입력받은 값을 우측에 저장후 좌측에 알맞은 답변 생성
//        dataList.add(new ChatData(msg,Code.ViewTypeRIGHT_CONTENT));
//        if(msg.equals("수강신청")){
//            dataList.add(new ChatData("수강신청에 대한 답변출력", Code.ViewType.LEFT_CONTENT));
//        }
    }


}