package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Calendar;

public class Crawl extends Activity {
    WebView mWebView;
    StringBuilder source;

    ArrayList<Element> elements = new ArrayList<>();
    int date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crawl);
        Log.i("onCreate 구엑:","시작");
        mWebView = (WebView)findViewById(R.id.webview);

        date = getDateDay();
        //date = 3;

        if (date<0){
            source.append("오늘은 주말입니다.");
            finishActivity();
        }
        else {
            mWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);

                    //<html></html>사이의 모든 값을 넘겨받음음
                    Log.i("onPageFinished 구엑 :","시작");
                    view.loadUrl("javascript:window.Android.getHtml(document.getElementsByTagName('html')[0].innerHTML);");
                    view.clearHistory();
                    view.clearCache(true);
                    Log.i("onPageFinished 구엑:","종료");
                }
            });
            //자바스크립트 사용을 허용
            mWebView.getSettings().setJavaScriptEnabled(true);

            mWebView.addJavascriptInterface(new MyJavascriptInterFace(), "Android");
            mWebView.loadUrl("https://www.daelim.ac.kr/cms/FrCon/index.do?MENU_ID=1470");
            Log.i("onCreate 구엑:","종료");
        }
    }

    protected class MyJavascriptInterFace{
        @JavascriptInterface
        public void getHtml(String html){ //위 자바스크립트가 호출되면 이곳으로 연결됨
            Log.i("자바스크립트 구엑:","호출");
            source = new StringBuilder();
            Document doc = Jsoup.parse(html);
            Elements Elements = doc.select("table.lineTop_tb2 tbody tr");

            for (Element ele : Elements){ elements.add(ele);} // Elements, 즉 원소값들을 전부 ArrayList에 넣음
            Element[] eletArr = elements.toArray(new Element[]{}); // ArrayList에 파싱한 Elements들을 element배열에 재대입
            int eleLen = eletArr.length-1;

            for (int i =0;i<eleLen-1;i++){ //for 문을 돌려서 현재 날짜의 식단표를 추출해 내보냄.
                if (eletArr[i].select("td").get(date).text() != "") {
                    source.append("\n" + eletArr[i].select("th").get(0).text() + " : "
                            + eletArr[i].select("td").get(date).text());
                    Log.i("포문 돌리기 구엑: ",Integer.toString(i));
                }
            }
            finishActivity();
            Log.i("자바스크립트 구엑:","종료");
        }
    }
    private void finishActivity(){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("result",source.toString());
        setResult(RESULT_OK,intent);
        finish();
    }

    protected int getDateDay(){
        int result;
        Calendar cal = Calendar.getInstance();
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);

        switch(dayOfWeek){
            case 2 :
                result = 0;
                break;
            case 3 :
                result = 1;
                break;
            case 4 :
                result = 2;
                break;
            case 5 :
                result = 3;
                break;
            case 6 :
                result = 4;
                break;
            default: result = -1;
        }
        return result;
    }

}
