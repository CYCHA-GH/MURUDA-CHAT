package com.example.chatbotleedaun;

import android.text.method.ScrollingMovementMethod;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;
import java.util.Calendar;

public class Crawl extends AppCompatActivity {
    WebView mWebView;
    String URL;
    String stdoc;
    String ask;
    StringBuilder source;
    ArrayList<Element> elements = new ArrayList<>();
    int date;

    public Crawl(String getask, String getUrl, String getdoc){
        String ask = getask;
        String Url = getUrl;
        String stdoc = getdoc.replaceAll("$$","");
        mWebView = (WebView)findViewById(R.id.webview);

        date = getDateDay();

        if (date<0){
            return;
        }
        else {
            mWebView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageFinished(WebView view, String url) {
                    super.onPageFinished(view, url);

                    //<html></html>사이의 모든 값을 넘겨받음음
                    view.loadUrl("javascript:window.Android.getHtml(document.getElementsByTagName('html')[0].innerHTML);");
                    view.clearHistory();
                    view.clearCache(true);
                    view.clearView();
                }
            });
            //자바스크립트 사용을 허용
            mWebView.getSettings().setJavaScriptEnabled(true);

            mWebView.addJavascriptInterface(new MyJavascriptInterFace(), "Android");
            mWebView.loadUrl(URL);
        }
    }
    protected class MyJavascriptInterFace{
        @JavascriptInterface
        public String pushHtmldata(String html){ //위 자바스크립트가 호출되면 이곳으로 연결됨
            source = new StringBuilder();

            source.append(ask + "");
            Document doc = Jsoup.parse(html);
            Elements Elements = doc.select(stdoc);

            for (Element ele : Elements){ elements.add(ele);} // Elements, 즉 원소값들을 전부 ArrayList에 넣음
            Element[] eletArr = elements.toArray(new Element[]{}); // ArrayList에 파싱한 Elements들을 element배열에 재대입
            int eleLen = eletArr.length-1;

            for (int i =0;i<eleLen-1;i++){ //for 문을 돌려서 현재 날짜의 식단표를 추출해 내보냄.
                if (eletArr[i].select("td").get(date).text() != "") {
                    source.append(eletArr[i].select("th").get(0).text() + " : "
                            + eletArr[i].select("td").get(date).text() + "\n\n");
                }
            }
            return source.toString();
        }
    }
    public int getDateDay(){
        int result;
        Calendar cal = Calendar.getInstance();
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);

        switch(dayOfWeek){
            case 1 :
                result = 0;
                break;
            case 2 :
                result = 1;
                break;
            case 3 :
                result = 2;
                break;
            case 4 :
                result = 3;
                break;
            case 5 :
                result = 4;
                break;
            default: result = -1;
        }
        return result;
    }
}
