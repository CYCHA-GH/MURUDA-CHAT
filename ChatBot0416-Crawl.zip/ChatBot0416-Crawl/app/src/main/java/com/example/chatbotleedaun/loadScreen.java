package com.example.chatbotleedaun;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class loadScreen extends AppCompatActivity {
    ImageView imgload;
    TextView txvloadtitle, txvloadsubtitle;
    private static final int _Width = 300;
    private static final int _Height = 400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_screen);

        imgload = (ImageView) findViewById(R.id.img_load);
        txvloadsubtitle = (TextView) findViewById(R.id.txb_loadsubtitle);
        txvloadtitle = (TextView) findViewById(R.id.txv_loadtitle);

        //애니메이션
        ObjectAnimator animator = ObjectAnimator.ofFloat(imgload, "translationY", imgload.getY()-200);
        Animation anim = AnimationUtils.loadAnimation(this,R.anim.alpha_anim);
        Animation anim2 = AnimationUtils.loadAnimation(this,R.anim.alpha_anim2);
        animator.setDuration(1000);
        animator.start();

        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() { public void run() {
            txvloadtitle.startAnimation(anim);
            txvloadtitle.setVisibility(View.VISIBLE);
            Handler mHandler = new Handler();
            mHandler.postDelayed(new Runnable() { public void run() {
                txvloadsubtitle.startAnimation(anim2);
                txvloadsubtitle.setVisibility(View.VISIBLE);
                Handler mHandler = new Handler();
                mHandler.postDelayed(new Runnable() { public void run() {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish(); }
                }, 1500); }
            }, 800);
                 }
            }, 800);
    }

}
