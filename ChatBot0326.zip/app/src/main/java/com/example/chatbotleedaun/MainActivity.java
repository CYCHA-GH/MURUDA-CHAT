package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<ChatData> dataList;
    private MyAdapter itemAdapter;

    EditText EditText_chat;
    Button Button_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button_send = findViewById(R.id.Button_send);
        EditText_chat = findViewById(R.id.EditText_chat);

        this.initializeData();
        itemAdapter = new MyAdapter(dataList);
        //Adapt,ChatData를 이용하여 채팅 내용 뽑기
        RecyclerView recyclerView = findViewById(R.id.recyclerview);

        LinearLayoutManager manager =
                new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(manager); //LayoutManager 등록
        recyclerView.setAdapter(itemAdapter); // Adapter 등록

        Button_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = EditText_chat.getText().toString();
                //입력받은 값을 우측에 출력후 좌측에 알맞은 답변 생성
                if((msg.getBytes().length<=0))  {
                    Toast.makeText(getApplicationContext(),"내용을 입력하세요",Toast.LENGTH_SHORT).show();
                }
                else{
                    dataList.add(new ChatData(msg, null, Code.ViewType.RIGHT_CONTENT));
                    itemAdapter.notifyDataSetChanged();
                    EditText_chat.setText("");
                    if (msg.replace(" ","").equals("수강신청")) {
                        dataList.add(new ChatData("수강신청에 대한 답변출력", null, Code.ViewType.LEFT_CONTENT));
                    }
                    else if (msg.replace(" ","").equals("컴퓨터정보학과")) {
                        dataList.add(new ChatData("아아 오지마세요..", null, Code.ViewType.LEFT_CONTENT));
                    }
                    recyclerView.scrollToPosition(dataList.size()-1);
                }
            }
        });
    }
    private void initializeData() {
        dataList = new ArrayList<>();
        //CENTER 출력
        dataList.add(new ChatData("머 루 다 \n",null,Code.ViewType.CENTER_CONTENT));
        //LEFT 출력
        dataList.add(new ChatData("안녕! 원하는 질문을 말해줘\n ex)수강신청,컴퓨터정보학과",null,Code.ViewType.LEFT_CONTENT));
    }
}