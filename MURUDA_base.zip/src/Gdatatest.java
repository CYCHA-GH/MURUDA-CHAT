import com.google.gdata.client.spreadsheet.*;

import java.net.URL;
import com.google.gdata.data.spreadsheet.*;
import java.util.*;

public class GdataTest {

    /**
     * @param args
     */

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        try{
            SpreadsheetService service = new SpreadsheetService("Gdata Test");
            service.setUserCredentials("", "");

            URL metafeedUrl = new       URL("https://spreadsheets.google.com/feeds/spreadsheets/private/full");
            SpreadsheetFeed feed = service.getFeed(metafeedUrl, SpreadsheetFeed.class);
            List<SpreadsheetEntry> spreadsheets = feed.getEntries();

            for(int i=0; i< spreadsheets.size(); i++)
            {
                SpreadsheetEntry entry = spreadsheets.get(i);
                if(entry.getTitle().getPlainText().equals("스프레드시트 파일 이름")) // 파일 타이틀
                {
                    List<WorksheetEntry> worksheets = entry.getWorksheets(); // 시트 타이틀
                    for(int k=0;k< worksheets.size();k++)
                    {
                        WorksheetEntry worksheet = worksheets.get(k);
                        System.out.println(worksheet.getTitle().getPlainText());

                        URL cellFeedUrl = worksheet.getCellFeedUrl();
                        CellFeed cellFeed = service.getFeed(cellFeedUrl, CellFeed.class);
                        for (CellEntry cell : cellFeed.getEntries())
                        {
                            System.out.println("getPlainText : "+cell.getTitle().getPlainText()); // value의 위치
                            System.out.println("getValue : "+cell.getCell().getValue()); // value의 내용
                        }
                    }
                }
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }

}