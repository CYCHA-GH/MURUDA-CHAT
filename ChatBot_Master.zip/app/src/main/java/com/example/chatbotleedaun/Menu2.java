package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu2 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);
        Tv_Title.setText("학과 / 학부");
        Tv_Content1.setText("건축학부\n\n" +
                "경영지원과\n\n" +
                "경영학부\n\n" +
                "기계과\n\n" +
                "도서관미디어정보과\n\n" +
                "디지털전자과\n\n" +
                "메카트로닉스과\n\n" +
                "미래자동차학부\n\n" +
                "반도체장비과\n\n" +
                "방송음향기술과\n\n" +
                "방송음향영상학부\n\n" +
                "보건의료기기과\n\n" +
                "비서학부\n\n" +
                "사회복지과\n\n" +
                "산업경영과\n\n" +
                "세무회계과\n\n" +
                "소방안전설비과\n\n" +
                "스마트소프트웨어과\n\n"+
                "스마트자동화과");
        Tv_Content2.setText("스마트전자통신학부\n\n"+
                "스마트팩토리학부\n\n" +
                "스포츠지도과\n\n" +
                "실내디자인학부\n\n" +
                "언어치료과\n\n" +
                "영상디자인과\n\n" +
                "유아교육과\n\n" +
                "의공융합과\n\n" +
                "전기과\n\n" +
                "전자통신과\n\n" +
                "제과제빵커피과\n\n" +
                "컴퓨터소프트웨어과\n\n" +
                "컴퓨터정보학부\n\n" +
                "토목환경과\n\n" +
                "항공서비스과\n\n" +
                "호텔관광과\n\n" +
                "호텔조리과\n\n" +
                "호텔조리학부");
    }
}