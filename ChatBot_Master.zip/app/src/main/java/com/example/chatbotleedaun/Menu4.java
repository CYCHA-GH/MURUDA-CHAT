package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu4 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);
        Tv_Title.setText("휴학 / 자퇴");
        Tv_Content1.setText("가사휴학 \n\n" +
                "군휴학 \n\n" +
                "복학\n\n" +
                "자퇴");
        Tv_Content2.setText("자퇴등록금반납\n\n" +
                "질병휴학\n\n" +
                "휴학 ");
    }
}