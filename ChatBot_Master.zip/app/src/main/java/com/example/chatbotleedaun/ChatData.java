package com.example.chatbotleedaun;

public class ChatData {

    private String content;
    private int viewType;

    public ChatData(String content, String msg ,int viewType) {
        this.content = content;
        this.viewType = viewType;
    }
    public String getContent() {
        return content;
    }

    public int getViewType() {
        return viewType;
    }
}
class Code {
    public class ViewType{
        public static final int LEFT_CONTENT = 0;
        public static final int RIGHT_CONTENT = 1;
        public static final int CENTER_CONTENT = 2;
    }
}
