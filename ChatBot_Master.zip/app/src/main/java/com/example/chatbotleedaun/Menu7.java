package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu7 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu7);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);

        Tv_Title.setText("설날에탁자위에서까먹는제주감귤");
        Tv_Content1.setText("201930432 \n\n" +
                "201730235 \n\n" +
                "201630122 \n\n" +
                "201930130 ");
        Tv_Content2.setText("차 찬 영 \n\n" +
                "최 준 원 \n\n" +
                "이 다 운 \n\n" +
                "정 현 진 ");
    }
}