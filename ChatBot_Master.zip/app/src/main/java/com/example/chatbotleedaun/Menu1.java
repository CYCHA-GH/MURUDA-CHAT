package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu1 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);
        Tv_Title.setText("학업관련");
        Tv_Content1.setText("강의평가\n" +
                "계절학기\n" +
                "등록금\n" +
                "로그인\n" +
                "성적조회\n" +
                "수강신청\n" +
                "원격수업");
        Tv_Content2.setText("자가진단평가방법\n" +
                "자기진단평가\n" +
                "전자출결\n" +
                "졸업학점\n" +
                "출결조회방법\n" +
                "학과일정\n" +
                "학사학위");
    }
}