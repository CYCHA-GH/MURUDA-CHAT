package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu5 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);
        Tv_Title.setText("뭔지 궁금해요");
        Tv_Content1.setText("대의원회 \n" +
                "동아리 \n" +
                "빅포레스트 \n" +
                "취업팀 ");
        Tv_Content2.setText("학과이름\n" +
                "학생경비 \n" +
                "학생회 \n" +
                "학생회비 ");
    }
}