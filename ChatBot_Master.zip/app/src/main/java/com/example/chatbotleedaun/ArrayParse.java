//package com.example.chatbotleedaun;
//
//import android.content.res.AssetManager;
//
//import org.json.JSONException;
//import org.json.JSONObject;
//import java.io.BufferedReader;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.InputStreamReader;
//
//public class ArrayParse {
//    public static void parse(){
//        AssetManager assetManager= getAssets();
//        try {
//            InputStream obj1 = assetManager.open("json/ask.json");
//            InputStream obj2 = assetManager.open("json/response.json");
//            InputStreamReader jObject1 = new InputStreamReader(obj1);
//            InputStreamReader jObject2 = new InputStreamReader(obj2);
//            BufferedReader reader1 = new BufferedReader(jObject1);
//            BufferedReader reader2 = new BufferedReader(jObject2);
//
//            StringBuffer buffer1 = new StringBuffer();
//            StringBuffer buffer2 = new StringBuffer();
//            String line1 = reader1.readLine();
//            String line2 = reader2.readLine();
//            while(line1!=null && line2!=null){
//                buffer1.append(line1+"\n");
//                line1 = reader1.readLine();
//                buffer2.append(line2+"\n");
//                line2 = reader2.readLine();
//            }
//            String jsonData1 = buffer1.toString();
//            String jsonData2 = buffer2.toString();
//
//            JSONObject jsonObject1 = new JSONObject(jsonData1);
//            JSONObject jsonObject2 = new JSONObject(jsonData2);
//            String ask = jsonObject1.getString("values");
//            String response = jsonObject2.getString("values");
//        }
//        catch (IOException e) {
//            e.printStackTrace();
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//    }
//}
