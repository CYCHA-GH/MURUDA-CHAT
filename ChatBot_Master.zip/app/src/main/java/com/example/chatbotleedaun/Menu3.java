package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu3 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);
        Tv_Title.setText("캠퍼스");
        Tv_Content1.setText("ATM \n\n" +
                "구내서점 \n\n" +
                "다산관 \n\n" +
                "대학본부관 \n\n" +
                "도서관 \n\n" +
                "보건실 \n\n" +
                "생활관 \n\n" +
                "서점 \n\n" +
                "셔틀버스 \n\n" +
                "수암관 \n\n" +
                "스마트스테이션 \n\n" +
                "아이디어박스 \n\n" +
                "안경점 \n\n" +
                "에이스스테이션 ");
        Tv_Content2.setText("원스톱지원실 \n\n" +
                "율곡관 \n\n" +
                "임곡관 \n\n" +
                "자동차관 \n\n" +
                "전산관 \n\n" +
                "정보통신관 \n\n" +
                "지도\n\n" +
                "카페 \n\n" +
                "퇴계관 \n\n" +
                "편의점 \n\n" +
                "학생식당 \n\n" +
                "학생회관 \n\n" +
                "한림관 \n\n" +
                "홍지관 ");
    }
}