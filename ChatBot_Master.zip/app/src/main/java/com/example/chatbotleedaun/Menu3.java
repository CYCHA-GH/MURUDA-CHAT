package com.example.chatbotleedaun;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Menu3 extends AppCompatActivity {

    TextView Tv_Title,Tv_Content1,Tv_Content2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);

        Tv_Title = findViewById(R.id.tv_title);
        Tv_Content1 = findViewById(R.id.tv_content1);
        Tv_Content2 = findViewById(R.id.tv_content2);
        Tv_Title.setText("캠퍼스");
        Tv_Content1.setText("ATM \n" +
                "구내서점 \n" +
                "다산관 \n" +
                "대학본부관 \n" +
                "도서관 \n" +
                "보건실 \n" +
                "생활관 \n" +
                "서점 \n" +
                "셔틀버스 \n" +
                "수암관 \n" +
                "스마트스테이션 \n" +
                "아이디어박스 \n" +
                "안경점 \n" +
                "에이스스테이션 ");
        Tv_Content2.setText("원스톱지원실 \n" +
                "율곡관 \n" +
                "임곡관 \n" +
                "자동차관 \n" +
                "전산관 \n" +
                "정보통신관 \n" +
                "지도\n" +
                "카페 \n" +
                "퇴계관 \n" +
                "편의점 \n" +
                "학생식당 \n" +
                "학생회관 \n" +
                "한림관 \n" +
                "홍지관 ");
    }
}